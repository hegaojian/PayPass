package com.hgj.paypass.fragment;

////////////////////////////////////////////////////////////////////
//                          _ooOoo_                               //
//                         o8888888o                              //
//                         88" . "88                              //
//                         (| ^_^ |)                              //
//                         O\  =  /O                              //
//                      ____/`---'\____                           //
//                    .'  \\|     |//  `.                         //
//                   /  \\|||  :  |||//  \                        //
//                  /  _||||| -:- |||||-  \                       //
//                  |   | \\\  -  /// |   |                       //
//                  | \_|  ''\---/''  |   |                       //
//                  \  .-\__  `-`  ___/-. /                       //
//                ___`. .'  /--.--\  `. . ___                     //
//              ."" '<  `.___\_<|>_/___.'  >'"".                  //
//            | | :  `- \`.;`\ _ /`;.`/ - ` : | |                 //
//            \  \ `-.   \_ __\ /__ _/   .-` /  /                 //
//      ========`-.____`-.___\_____/___.-`____.-'========         //
//                           `=---='                              //
//      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^        //
//         佛祖保佑       永无BUG     永不修改                        //
////////////////////////////////////////////////////////////////////

import android.animation.Animator;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.hgj.paypass.R;
import com.hgj.paypass.ui.SetPassActivity;
import com.hgj.paypass.view.OnPasswordInputFinish;
import com.hgj.paypass.view.PassView;

/**
 * 确认密码Fragment
 * @author hgj
 */

public class ConfimPassFragment extends Fragment implements OnPasswordInputFinish {
    PassView passPay;
    boolean isclear = false;
    public static ConfimPassFragment newInstance() {
        Bundle args = new Bundle();
        ConfimPassFragment fragment = new ConfimPassFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        passPay = new PassView(getActivity());
        passPay.setOnFinishInput(this);
        passPay.title.setText("请再次输入，以确认密码");
        return passPay;
    }

    @Override
    public void inputFinish() {
        if(!((SetPassActivity)getActivity()).passStr.equals(passPay.getStrPassword())){
            passPay.tips.setText("两次输入不一致，请重新设置");
            passPay.tips.setTextColor(ContextCompat.getColor(getActivity(), R.color.error));
            check();
        }else{
            if(((SetPassActivity)getActivity()).update){
                updatePass(passPay.getStrPassword());
            }else{
                setPass(passPay.getStrPassword());
            }
        }
    }

    @Override
    public void inputFirst() {

    }

    public void check(){
        TextView[] textViews =  passPay.tvList;
        isclear = false;
        for (TextView textview:textViews) {
            YoYo.with(Techniques.Shake)
                    .duration(700)
                    .repeat(0)
                    .onEnd(new YoYo.AnimatorCallback() {
                        @Override
                        public void call(Animator animator) {
                            if(!isclear){
                                passPay.clearText();
                                ((SetPassActivity)getActivity()).passViewpager.setCurrentItem(0);
                                isclear = true;
                                passPay.tips.setTextColor(ContextCompat.getColor(getActivity(),R.color.gray));
                                passPay.tips.setText("请不要设置完全连续或完全重复的数字");
                            }
                        }
                    })
                    .playOn(textview);
        }
        YoYo.with(Techniques.Shake)
                .duration(700)
                .repeat(0)
                .playOn(passPay.tips);
    }

    /**
     * 设置密码接口
     * @param pass
     */
    public void setPass(String pass) {
        Toast.makeText(getActivity(),"密码设置成功",Toast.LENGTH_SHORT).show();
        getActivity().finish();
        //细节注意，若调用设置密码接口失败，需要返回上一层 可调用以下代码
       /* passPay.clearText();
        ((SetPassActivity)getActivity()).backtype=1;
        ((SetPassActivity)getActivity()).passViewpager.setCurrentItem(0);
        passPay.tips.setTextColor(ContextCompat.getColor(getActivity(),R.color.gray));
        passPay.tips.setText("请不要设置完全连续或完全重复的数字");*/
    }

    /**
     * 修改密码接口
     * @param newpass
     */
    public void updatePass(String newpass) {
        Toast.makeText(getActivity(),"密码修改成功",Toast.LENGTH_SHORT).show();
        getActivity().finish();
        //细节注意，若调用修改密码接口失败，需要返回上一层 可调用以下代码
       /* passPay.clearText();
        ((SetPassActivity)getActivity()).backtype=1;
        ((SetPassActivity)getActivity()).passViewpager.setCurrentItem(0);
        passPay.tips.setTextColor(ContextCompat.getColor(getActivity(),R.color.gray));
        passPay.tips.setText("请不要设置完全连续或完全重复的数字");*/
    }
}
