package com.hgj.paypass;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.hgj.paypass.ui.CheckPassActivity;
import com.hgj.paypass.ui.SetPassActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((Toolbar)findViewById(R.id.toolbar)).setTitle("PayPass");
        findViewById(R.id.nopass).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SetPassActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.havepass).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CheckPassActivity.class);
                startActivity(intent);
            }
        });
    }
}
