package com.hgj.paypass.ui;

////////////////////////////////////////////////////////////////////
//                          _ooOoo_                               //
//                         o8888888o                              //
//                         88" . "88                              //
//                         (| ^_^ |)                              //
//                         O\  =  /O                              //
//                      ____/`---'\____                           //
//                    .'  \\|     |//  `.                         //
//                   /  \\|||  :  |||//  \                        //
//                  /  _||||| -:- |||||-  \                       //
//                  |   | \\\  -  /// |   |                       //
//                  | \_|  ''\---/''  |   |                       //
//                  \  .-\__  `-`  ___/-. /                       //
//                ___`. .'  /--.--\  `. . ___                     //
//              ."" '<  `.___\_<|>_/___.'  >'"".                  //
//            | | :  `- \`.;`\ _ /`;.`/ - ` : | |                 //
//            \  \ `-.   \_ __\ /__ _/   .-` /  /                 //
//      ========`-.____`-.___\_____/___.-`____.-'========         //
//                           `=---='                              //
//      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^        //
//         佛祖保佑       永无BUG     永不修改                        //
////////////////////////////////////////////////////////////////////

import android.animation.Animator;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.hgj.paypass.R;
import com.hgj.paypass.view.OnPasswordInputFinish;
import com.hgj.paypass.view.PassView;

/**
 * 身份验证
 * @author hgj
 */

public class CheckPassActivity extends AppCompatActivity implements OnPasswordInputFinish {

    PassView passPay;
    boolean isclear = false;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkpass);
        init();
    }

    public void init(){
        passPay = findViewById(R.id.pass_pay);
        passPay.setOnFinishInput(this);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("身份验证");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
        passPay.tips.setVisibility(View.GONE);
        passPay.title.setText("请输入支付密码");

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public void inputFinish() {
        validPass(passPay.getStrPassword());
    }

    @Override
    public void inputFirst() {
        passPay.tips.setVisibility(View.GONE);
    }

    public void check() {
        TextView[] textViews = passPay.tvList;
        isclear = false;
        for (TextView textview : textViews) {
            YoYo.with(Techniques.Shake)
                    .duration(700)
                    .repeat(0)
                    .onEnd(new YoYo.AnimatorCallback() {
                        @Override
                        public void call(Animator animator) {
                            if (!isclear) {
                                passPay.clearText();
                                isclear = true;
                            }
                        }
                    })
                    .playOn(textview);
        }
        YoYo.with(Techniques.Shake)
                .duration(700)
                .repeat(0)
                .playOn(passPay.tips);
    }

    /**
     * 验证密码接口
     * @param pass
     */
    public void validPass(String pass) {
        //验证通过
        if(pass.equals("747474")){
            Intent intent = new Intent(CheckPassActivity.this,SetPassActivity.class);
            intent.putExtra("update",true);
            startActivity(intent);
            finish();
        }else{
            passPay.tips.setVisibility(View.VISIBLE);
            passPay.tips.setText("支付密码错误，请重新输入");
            passPay.tips.setTextColor(ContextCompat.getColor(CheckPassActivity.this, R.color.error));
            check();
        }

    }
}
