package com.hgj.paypass.fragment;

////////////////////////////////////////////////////////////////////
//                          _ooOoo_                               //
//                         o8888888o                              //
//                         88" . "88                              //
//                         (| ^_^ |)                              //
//                         O\  =  /O                              //
//                      ____/`---'\____                           //
//                    .'  \\|     |//  `.                         //
//                   /  \\|||  :  |||//  \                        //
//                  /  _||||| -:- |||||-  \                       //
//                  |   | \\\  -  /// |   |                       //
//                  | \_|  ''\---/''  |   |                       //
//                  \  .-\__  `-`  ___/-. /                       //
//                ___`. .'  /--.--\  `. . ___                     //
//              ."" '<  `.___\_<|>_/___.'  >'"".                  //
//            | | :  `- \`.;`\ _ /`;.`/ - ` : | |                 //
//            \  \ `-.   \_ __\ /__ _/   .-` /  /                 //
//      ========`-.____`-.___\_____/___.-`____.-'========         //
//                           `=---='                              //
//      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^        //
//         佛祖保佑       永无BUG     永不修改                        //
////////////////////////////////////////////////////////////////////

import android.animation.Animator;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.hgj.paypass.R;
import com.hgj.paypass.ui.SetPassActivity;
import com.hgj.paypass.util.PayUtil;
import com.hgj.paypass.view.OnPasswordInputFinish;
import com.hgj.paypass.view.PassView;

/**
 * 设置密码Fragment
 * @author hgj
 */
public class SetPassFragment extends Fragment implements OnPasswordInputFinish {
    PassView passPay;
    boolean isclear = false;
    public static SetPassFragment newInstance() {
        Bundle args = new Bundle();
        SetPassFragment fragment = new SetPassFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        passPay = new PassView(getActivity());
        passPay.setOnFinishInput(this);
        return passPay;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void inputFinish() {
        if(PayUtil.isAsc(passPay.getStrPassword())){
            passPay.tips.setText("请不要设置完全连续的数字");
            passPay.tips.setTextColor(ContextCompat.getColor(getActivity(), R.color.error));
            check();
        }else if(PayUtil.isSame(passPay.getStrPassword())){
            passPay.tips.setText("请不要设置完全重复的数字");
            passPay.tips.setTextColor(ContextCompat.getColor(getActivity(),R.color.error));
            check();
        }else{
            ((SetPassActivity)getActivity()).passViewpager.setCurrentItem(1);
            ((SetPassActivity)getActivity()).passStr = passPay.getStrPassword();
        }
    }

    @Override
    public void inputFirst() {
        passPay.tips.setTextColor(ContextCompat.getColor(getActivity(),R.color.gray));
        passPay.tips.setText("请不要设置完全连续或完全重复的数字");
    }

    public void check(){
        TextView[] textViews =  passPay.tvList;
        isclear = false;
        for (TextView textview:textViews) {
            YoYo.with(Techniques.Shake)
                    .duration(700)
                    .repeat(0)
                    .onEnd(new YoYo.AnimatorCallback() {
                        @Override
                        public void call(Animator animator) {
                            if(!isclear){
                                passPay.clearText();
                                isclear = true;
                            }
                        }
                    })
                    .playOn(textview);
        }
        YoYo.with(Techniques.Shake)
                .duration(700)
                .repeat(0)
                .playOn(passPay.tips);
    }

    public void setError(){
        passPay.clearText();
        passPay.tips.setText("两次输入不一致，请重新设置");
        passPay.tips.setTextColor(ContextCompat.getColor(getActivity(),R.color.error));
    }
    public void clear(){
        passPay.clearText();
    }
}
