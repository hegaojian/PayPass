package com.hgj.paypass.ui;

////////////////////////////////////////////////////////////////////
//                          _ooOoo_                               //
//                         o8888888o                              //
//                         88" . "88                              //
//                         (| ^_^ |)                              //
//                         O\  =  /O                              //
//                      ____/`---'\____                           //
//                    .'  \\|     |//  `.                         //
//                   /  \\|||  :  |||//  \                        //
//                  /  _||||| -:- |||||-  \                       //
//                  |   | \\\  -  /// |   |                       //
//                  | \_|  ''\---/''  |   |                       //
//                  \  .-\__  `-`  ___/-. /                       //
//                ___`. .'  /--.--\  `. . ___                     //
//              ."" '<  `.___\_<|>_/___.'  >'"".                  //
//            | | :  `- \`.;`\ _ /`;.`/ - ` : | |                 //
//            \  \ `-.   \_ __\ /__ _/   .-` /  /                 //
//      ========`-.____`-.___\_____/___.-`____.-'========         //
//                           `=---='                              //
//      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^        //
//         佛祖保佑       永无BUG     永不修改                        //
////////////////////////////////////////////////////////////////////

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.hgj.paypass.R;
import com.hgj.paypass.adapter.PagerAdapter;
import com.hgj.paypass.fragment.ConfimPassFragment;
import com.hgj.paypass.fragment.SetPassFragment;
import com.hgj.paypass.view.NoScrollViewPager;
import com.hgj.paypass.view.ViewPagerScroller;

import java.util.ArrayList;
import java.util.List;

/**
 * 设置密码Activity
 * @author hgj
 */

public class SetPassActivity extends AppCompatActivity {
    Toolbar toolbar;
    public NoScrollViewPager passViewpager;
    List<Fragment> fragments = new ArrayList<>();
    public String passStr;
    public String oldpassStr;
    public boolean update;
    public int backtype=0;//默认0为确认密码与设置设置密码不一致时返回至设置密码的操作 1为确认密码验证成功去提交，因某些
    //未知原因 ，如无网络，或请求失败时返回时的操作
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_page);
        init();
    }
    public void init(){
        toolbar = findViewById(R.id.toolbar);
        passViewpager = findViewById(R.id.pass_viewpager);
        toolbar.setTitle("设置支付密码");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
        fragments.add(SetPassFragment.newInstance());
        fragments.add(ConfimPassFragment.newInstance());
        update =  getIntent().getBooleanExtra("update",false);
        oldpassStr =  getIntent().getStringExtra("pass");
        passViewpager.setAdapter(new PagerAdapter(getSupportFragmentManager(),fragments));
        passViewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if(position==0){
                    SetPassFragment setPassFragment = (SetPassFragment) fragments.get(0);
                    if(backtype==0){
                        setPassFragment.setError();
                    }else{
                        setPassFragment.clear();
                        backtype = 0;
                    }

                }

            }
            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        ViewPagerScroller pagerScroller = new ViewPagerScroller(this);
        pagerScroller.initViewPagerScroll(passViewpager);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });
    }
    @Override
    public void onBackPressed() {
        showDialog();
    }

    public void showDialog(){
        new MaterialDialog.Builder(this)
                .title("温馨提示")
                .content("确认放弃设置支付密码吗")
                .contentColorRes(R.color.black)
                .positiveText("确认放弃")
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.cancel();
                        finish();
                    }
                }).negativeText("继续设置")
                .onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.cancel();
                    }
                }).show();
    }
}
